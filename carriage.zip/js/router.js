var thishref = window.location.href;
// window.location.href = thishref+"?page="+page_text;
// $("")
console.log(thishref);
